#!/usr/bin/env python3
"""hookscore.py - score a YouTube hook before you waste a take on it.

Five properties, 0-100 each, and a verdict that is 60% the mean and 40% the weakest one. The
weakest-link weighting is deliberate: a hook with four strong properties and one dead one is a hook
that leaks at the dead one, and averaging hides that.

    python3 hookscore.py hooks.txt            # one hook per line, ranked
    python3 hookscore.py --hook "one line"    # score a single hook
    python3 hookscore.py --json hooks.txt     # machine-readable

WHAT THIS CAN AND CANNOT TELL YOU. Measured against 74 real short-form hooks (first 15 seconds of
auto-captions, top-8 and bottom-8 by views across five channels): it separates deliberately bad
hooks from real ones well, and it separates a creator's own hits from their own misses barely at
all. Treat a low score as a reason to look again, never a high score as a promise.
"""
import json, os, re, sys

HERE = os.path.dirname(os.path.abspath(__file__))
FORMULAS = json.load(open(os.path.join(HERE, "hooks.json"), encoding="utf-8"))["hooks"]
if hasattr(sys.stdout, "reconfigure"): sys.stdout.reconfigure(encoding="utf-8")

# Persian (fa) patch, 2026-11-05: every word list below carries its colloquial Persian twin, and text is
# normalised first (Persian digits -> ASCII, Arabic ي/ك -> ی/ک, ZWNJ dropped) so میتونی and می‌تونی match alike.
FA_CHARS = re.compile(r"[؀-ۿ]")
def fa_norm(t):
    t = t.translate(str.maketrans("۰۱۲۳۴۵۶۷۸۹٠١٢٣٤٥٦٧٨٩يك٪", "01234567890123456789یک%"))
    return t.replace("‌", "").replace("‏", "").replace("‎", "")
def is_fa(t): return bool(FA_CHARS.search(t))

FILLER = {"basically","actually","literally","just","really","very","so","kind","sort","like",
          "guys","hey","welcome","today","video","subscribe","channel",
          "واقعا","دقیقا","اصلا","فقط","خیلی","سلام","دوستان","بچهها","امروز","ویدیو","ویدئو","سابسکرایب",
          "کانال","لایک","فالو","یعنی","خب","حالا","راستش"}
VAGUE = {"amazing","incredible","insane","crazy","huge","massive","game","changer","secret",
         "powerful","ultimate","best","revolutionary","mind","blowing","unbelievable",
         "فوقالعاده","باورنکردنی","دیوانهکننده","انقلابی","بهترین","خفن","عالی","بینظیر","شگفتانگیز",
         "معجزه","راز","قدرتمند","ترکوند","نابغه","رویایی","جادویی"}
CONCRETE = re.compile(r"\b(\d[\d,.]*\s?(%|k|m|x|s|m|h)?|\$\d|\d+\s?(second|minute|hour|day|week|month|year)s?)\b"
                      r"|\b(یک|یه|دو|سه|چهار|پنج|شش|هفت|هشت|نه|ده|یازده|دوازده|بیست|سی|صد|هزار|میلیون)\s?"
                      r"(تا|درصد|دلار|تومن|روز|هفته|ماه|سال|ثانیه|دقیقه|ساعت|برابر)\b", re.I)
YOU = re.compile(r"\b(you|your|you're|youre|yourself)\b"
                 r"|\b(تو|شما|خودت|خودتون|بهت|بهتون|برات|براتون|ازت|باهات|واست|داری|دارین|کردی|بکنی|بیاری|بسازی|"
                 r"بدونی|ببینی|بزنی|بری|ببین|ببینید|ببینین|بساز|بسازین|بزن|بنویس|ن?می\w+ی|ن?می\w+ین|ن?می\w+ید|(کانال|پیج|ویدیو|ویدئو|پول|درآمد|وقت|بیزینس|محتوا|مخاطب)تو?ن?)\b", re.I)
STAKE = re.compile(r"\b(lose|lost|wasting|waste|quit|fail|broke|cost|risk|before|stop|never|die|dying|dead)\b"
                   r"|\b(از دست|ضرر|هدر|باختی|نابود|سوخت|پول|هزینه|گرون|اشتباه|قبل از|نکن|هرگز|هیچوقت|ورشکست|"
                   r"عقب|دلار|تومن|درآمد|بیکار|ول کن)", re.I)
CURIOSITY = re.compile(r"\b(why|how|what|which|until|before|but|nobody|almost|except|reason|actually)\b"
                       r"|\b(چرا|چطور|چطوری|چی|کدوم|تا وقتی|قبل از|ولی|اما|هیچکس|کسی بهت نمیگه|تقریبا|جز|دلیل|نمیدونی)\b", re.I)

def words(t): return re.findall(r"[a-z0-9'%$.؀-ۿ]+", t.lower())

def specificity(t):
    w = words(t)
    if not w: return 0
    nums = len(CONCRETE.findall(t))
    vague = sum(1 for x in w if x in VAGUE or x.removesuffix("ترین") in VAGUE)
    filler = sum(1 for x in w if x in FILLER)
    s = 34 + nums * 22 - vague * 16 - filler * 5
    # proper nouns that are not sentence-initial read as named things
    s += min(18, 6 * sum(1 for x in t.split()[1:] if x[:1].isupper()))
    # Persian has no capitals: Latin-script names (Claude, YouTube) inside Persian text are the named things
    if is_fa(t): s += min(18, 6 * len(re.findall(r"\b[A-Za-z][A-Za-z0-9.]+\b", t)))
    return max(0, min(100, s))

def address(t):
    n = len(YOU.findall(t))
    first = 30 if YOU.search(" ".join(t.split()[:6])) else 0
    return max(0, min(100, 26 + n * 20 + first))

def stakes(t):
    n = len(STAKE.findall(t))
    return max(0, min(100, 22 + n * 26 + (14 if CONCRETE.search(t) else 0)))

def curiosity(t):
    n = len(CURIOSITY.findall(t))
    q = 18 if t.strip().endswith(("?", "؟")) else 0
    # a hook that resolves itself has no gap left
    closed = -18 if re.search(r"\b(because|so that|which means|چون|برای اینکه|به خاطر اینکه)\b", t, re.I) else 0
    return max(0, min(100, 24 + n * 17 + q + closed))

def brevity(t):
    n = len(words(t))
    if n == 0: return 0
    # 9-24 words is the band a spoken hook lands in at ~150wpm inside 10 seconds
    if 9 <= n <= 24: return 100
    if n < 9:  return max(30, 100 - (9 - n) * 11)
    return max(10, 100 - (n - 24) * 7)

PROPS = [("SPECIFICITY", specificity), ("ADDRESS", address), ("STAKES", stakes),
         ("CURIOSITY", curiosity), ("BREVITY", brevity)]

def classify(t):
    t = fa_norm(t)
    best, hits = None, 0
    for f in FORMULAS:
        n = sum(1 for p in f["match"] if re.search(p, t, re.I))
        if n > hits: best, hits = f, n
    if not best: return "Unclassified", hits
    return (f'{best["name"]} / {best["name_fa"]}' if is_fa(t) and best.get("name_fa") else best["name"]), hits

def score(t):
    t = fa_norm(t)
    parts = {n: fn(t) for n, fn in PROPS}
    vals = list(parts.values())
    verdict = round(0.6 * (sum(vals) / len(vals)) + 0.4 * min(vals))
    name, hits = classify(t)
    return parts, verdict, name, hits

def band(v): return "STRONG" if v >= 72 else "WORKABLE" if v >= 55 else "WEAK"

def report(t, parts, verdict, name, hits):
    print(f"\n  {t.strip()}")
    print(f"  {'-' * min(72, max(20, len(t.strip())))}")
    for k, v in parts.items():
        print(f"    {k:<12} {v:3d}  {'#' * (v // 5)}")
    print(f"    {'VERDICT':<12} {verdict:3d}  {band(verdict)}")
    print(f"    formula      {name}" + (f"  ({hits} pattern{'s' if hits != 1 else ''} matched)" if hits else "  (no formula matched - that is usually a summary, not a hook)"))
    low = min(parts, key=parts.get)
    print(f"    weakest      {low} - {(FIX_FA if is_fa(t) else FIX)[low]}")

FIX = {
 "SPECIFICITY": "swap one adjective for a number, a name or a date",
 "ADDRESS": "say 'you' in the first six words",
 "STAKES": "name what it costs them to keep doing it the current way",
 "CURIOSITY": "cut the half of the sentence that answers itself",
 "BREVITY": "9 to 24 words. Read it out loud and stop where you run out of breath",
}

FIX_FA = {
 "SPECIFICITY": "یه صفت رو با یه عدد، اسم یا تاریخ عوض کن",
 "ADDRESS": "تو شش کلمه‌ی اول بیننده رو مستقیم خطاب کن (تو / کانالت / می‌تونی)",
 "STAKES": "بگو اگه همین‌جوری ادامه بده چی از دست می‌ده",
 "CURIOSITY": "نصفه‌ی جمله که خودش جواب خودشه رو حذف کن",
 "BREVITY": "۹ تا ۲۴ کلمه. بلند بخونش و هر جا نفست تموم شد، تمومش کن",
}

def main():
    a = sys.argv[1:]
    as_json = "--json" in a
    a = [x for x in a if x != "--json"]
    if "--hook" in a:
        lines = [a[a.index("--hook") + 1]]
    elif a and os.path.exists(a[0]):
        lines = [l for l in open(a[0], encoding="utf-8-sig").read().splitlines() if l.strip()]
    else:
        print(__doc__); sys.exit(1 if not a else 0)
    out = []
    for t in lines:
        parts, verdict, name, hits = score(t)
        out.append({"hook": t.strip(), "properties": parts, "verdict": verdict,
                    "band": band(verdict), "formula": name, "matched": hits})
    out.sort(key=lambda r: -r["verdict"])
    if as_json:
        print(json.dumps([{k: v for k, v in r.items() if k != "matched"} for r in out], indent=1)); return
    for r in out:
        report(r["hook"], r["properties"], r["verdict"], r["formula"], r["matched"])
    if len(out) > 1:
        print(f"\n  winner: {out[0]['hook'].strip()}  ({out[0]['verdict']}, {out[0]['band']})\n")

if __name__ == "__main__":
    main()
